Deploy Static Website on AWS

A static website to AWS using S3, CloudFront, and IAM.

STATIC WEBSITE LINK: http://my-881423144151-bucket.s3-website-us-east-1.amazonaws.com/

CLOUDFRONT CDN LINK: https://d1p6cfd1oadi4g.cloudfront.net



NAME: KELVIN OMOZOKPIA
EMAIL: KELVINJUNE2@GMAIL.COM


THANKS ALOT.